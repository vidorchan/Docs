package com.tuling.entity;

import lombok.Data;

/**
 * Created by smlz on 2019/3/26.
 */
@Data
public class User {

    private Integer userId;

    private String userName;

    private String sex;
}
