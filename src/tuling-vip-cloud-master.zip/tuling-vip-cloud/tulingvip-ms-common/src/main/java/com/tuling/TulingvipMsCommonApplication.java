package com.tuling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

public class TulingvipMsCommonApplication {

	public static void main(String[] args) {
		SpringApplication.run(TulingvipMsCommonApplication.class, args);
	}

}
