package com.tuling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

public class Tulingvip02MsFeignApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Tulingvip02MsFeignApiApplication.class, args);
	}

}
