package com.tuling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tulingvip02MsConsumerRibbon8001Application {

	public static void main(String[] args) {
		SpringApplication.run(Tulingvip02MsConsumerRibbon8001Application.class, args);
	}

}
