package com.tuling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tulingvip01MsConsumerUser8001Application {

	public static void main(String[] args) {
		SpringApplication.run(Tulingvip01MsConsumerUser8001Application.class, args);
	}

}
