package com.tuling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tulingvip05MsConfigClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(Tulingvip05MsConfigClientApplication.class, args);
	}

}
