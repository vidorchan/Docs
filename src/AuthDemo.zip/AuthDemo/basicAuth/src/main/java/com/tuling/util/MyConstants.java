package com.tuling.util;

public class MyConstants {

    public static final String FLAG_CURRENTUSER = "currnetUser";

    public static final String RESOURCE_COMMON = "common";
    public static final String RESOURCE_MOBILE = "mobile";
    public static final String RESOURCE_SALARY = "salary";
}
